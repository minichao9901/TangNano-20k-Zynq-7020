/*
 * Copyright (c) 2009 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 */

#include <stdio.h>
#include "platform.h"
#include <xil_io.h>
#include <xintc.h>
#include <xparameters.h>
#include <xil_exception.h>

/************************** Constant Definitions *****************************/

#define FAST_IRQ_EN 1

/*
 * The following constants map to the names of the hardware instances that
 * were created in the EDK XPS system.  They are only defined here such that
 * a user can easily change all the needed device IDs in one place.
 */
#define IRQ_GEN_ID				0
#define IRQ_GEN_INTERRUPT_ID	XPAR_MICROBLAZE_0_INTC_IRQ_GEN_0_IRQ_INTR

#define INTC_DEVICE_ID	XPAR_INTC_0_DEVICE_ID
#define INTC			XIntc
#define INTC_HANDLER	XIntc_InterruptHandler

#define IRQ_PCORE_GEN_BASE  XPAR_IRQ_GEN_0_BASEADDR

// base address of PS Uart1
#define UART_BASE 0xE0001000

// OCM memory used to communicate with CPU0
#define COMM_VAL  (*(volatile u32 *)(0xFFFF0000))


/**************************** Type Definitions *******************************/

/**
 * This typedef contains configuration information for the device driver.
 */
typedef struct {
	u16 DeviceId;		/**< Unique ID of device */
	u32 BaseAddress;	/**< Base address of the device */
} IrqGen_Config;


/**
 * The driver instance data. The user is required to allocate a
 * variable of this type.
 * A pointer to a variable of this type is then passed to the driver API
 * functions.
 */
typedef struct {
	IrqGen_Config Config;   /**< Hardware Configuration */
	u32 IsReady;		/**< Device is initialized and ready */
	u32 IsStarted;		/**< Device is running */
} XIrqGenIrq;


/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/

int SetupInterruptSystem();
void XUartChanged_SendByte(u32 BaseAddress, u8 Data);
void outbyte(char c);

#ifdef FAST_IRQ_EN
static void IrqGenIntrHandler(void *CallBackRef) __attribute__((fast_interrupt));
#else
static void IrqGenIntrHandler(void *CallBackRef);
#endif


/************************** Variable Definitions *****************************/

static INTC Intc; 						/* The Instance of the Interrupt Controller Driver */
static XIrqGenIrq IrqGenInstancePtr;	/* The Instance of the IrqGen Driver */


volatile static int irq_count;					// Global for IRQ communication to main()


/****************************************************************************/
/**
* This function is the main function for the Microblaze in the AMP PS/MB xapp
* It is responsible for initializing the irq generator device, setting up
* interrupts, communicating with the PS via OCM, and writing output to the
* PS UART
*
* @param	None.
*
* @return
*		- XST_SUCCESS to indicate success.
*		- XST_FAILURE to indicate Failure.
*
* @note		None.
*
*
*****************************************************************************/
int main(void)
{
	int Status;

    init_platform();

    irq_count = 0;

    // Initialize driver instance for IrqGen IRQ
    IrqGenInstancePtr.Config.DeviceId = IRQ_GEN_ID;
    IrqGenInstancePtr.Config.BaseAddress = IRQ_PCORE_GEN_BASE;
    IrqGenInstancePtr.IsReady = XIL_COMPONENT_IS_READY;
    IrqGenInstancePtr.IsStarted = 0;

	/*
	 * Setup the interrupts such that interrupt processing can occur. If
	 * an error occurs then exit
	 */
	Status = SetupInterruptSystem();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

    while(1) {
    	//wait until CPU0 hands off flag
    	while(COMM_VAL == 0);
        xil_printf("MB0 : Waiting for IRQ\n\r");

    	while(irq_count == 0);

        xil_printf("MB0 : IRQ Acknowledged\n\r");
        irq_count = 0;

    	// Wait until UART TX FIFO is empty
    	while ((Xil_In32(UART_BASE + 0x2C) & 0x08) != 0x08);

        //pass control to CPU0
        COMM_VAL = 0;
    }

    cleanup_platform();

    return XST_SUCCESS;
}


/****************************************************************************/
/**
* This function contains the low level code to write a character to the PS
* UART
*
* @param	BaseAddress contains the base address of the PS UART
* @param	Data contains the value to write to the UART tx fifo
*
* @return	None.
*
* @note		None.
*
*****************************************************************************/
void XUartChanged_SendByte(u32 BaseAddress, u8 Data)
{
	// Wait until there is space in TX FIFO
	while ((Xil_In32((BaseAddress + 0x2C) & 0x10)) == 0x10);

	// Write the byte into the TX FIFO
	Xil_Out32((BaseAddress+0x30), Data);
}


/****************************************************************************/
/**
* This function is used by xil_printf() to print a character to stdout;
* The BSP was not configured for stdout since the PS UART is not visible
* by the BSP.
*
* @param	c contains the value to print
*
* @return	None.
*
* @note		None.
*
*****************************************************************************/
void outbyte(char c) {
	 XUartChanged_SendByte(UART_BASE, c);
}


/****************************************************************************/
/**
* This function sets up the interrupt system for the example.  The processing
* contained in this funtion assumes the hardware system was built with
* and interrupt controller.
*
* @param	None.
*
* @return	A status indicating XST_SUCCESS or a value that is contained in
*		xstatus.h.
*
* @note		None.
*
*****************************************************************************/
int SetupInterruptSystem()
{
	int Result;
	INTC *IntcInstancePtr = &Intc;

	/*
	 * Initialize the interrupt controller driver so that it's ready to use.
	 * specify the device ID that was generated in xparameters.h
	 */
	Result = XIntc_Initialize(IntcInstancePtr, INTC_DEVICE_ID);
	if (Result != XST_SUCCESS) {
		return Result;
	}

	/* Hook up interrupt service routine */
#ifdef FAST_IRQ_EN
	XIntc_ConnectFastHandler(IntcInstancePtr, IRQ_GEN_INTERRUPT_ID,
		      (XFastInterruptHandler)IrqGenIntrHandler);
#else
	XIntc_Connect(IntcInstancePtr, IRQ_GEN_INTERRUPT_ID,
		      (Xil_ExceptionHandler)IrqGenIntrHandler, &IrqGenInstancePtr);
#endif

	/* Enable the interrupt vector at the interrupt controller */

	XIntc_Enable(IntcInstancePtr, IRQ_GEN_INTERRUPT_ID);

	/*
	 * Start the interrupt controller such that interrupts are recognized
	 * and handled by the processor
	 */
	Result = XIntc_Start(IntcInstancePtr, XIN_REAL_MODE);
	if (Result != XST_SUCCESS) {
		return Result;
	}

	/*
	 * Initialize the exception table and register the interrupt
	 * controller handler with the exception table
	 */
	Xil_ExceptionInit();

	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
			 (Xil_ExceptionHandler)INTC_HANDLER, IntcInstancePtr);

	/* Enable non-critical exceptions */
	Xil_ExceptionEnable();

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function is the Interrupt handler for the PL Interrupt.
* It is called when the PL creates an interrupt and the interrupt gets serviced.
*
* This function sets the global varialbe irq_count=1 and clears the interrupt source.
*
* @param	CallBackRef is a pointer to the callback function.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
static void IrqGenIntrHandler(void *CallBackRef)
{

//	XIrqGenIrq *InstancePtr = (XIrqGenIrq *)CallBackRef;

	/*
	 * Clear the interrupt source
	 */
	Xil_Out32(IrqGenInstancePtr.Config.BaseAddress, 0);
//	Xil_Out32(InstancePtr->Config.BaseAddress, 0);

	irq_count = 1;

}

